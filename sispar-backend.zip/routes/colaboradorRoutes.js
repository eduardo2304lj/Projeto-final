const express = require('express');
const router = express.Router();
const { cadastrarColaborador, listarColaboradores } = require('../controllers/colaboradorController');

router.post('/', cadastrarColaborador);
router.get('/', listarColaboradores);

module.exports = router;