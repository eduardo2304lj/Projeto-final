const express = require('express');
const router = express.Router();
const { criarReembolso, buscarPorNumeroPrestacao } = require('../controllers/reembolsoController');

router.post('/', criarReembolso);
router.get('/:numero', buscarPorNumeroPrestacao);

module.exports = router;