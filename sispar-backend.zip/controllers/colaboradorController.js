const pool = require('../config/db');

exports.cadastrarColaborador = async (req, res) => {
  const { nome, email, senha, cargo, salario } = req.body;
  try {
    await pool.query(
      'INSERT INTO colaboradores (nome, email, senha, cargo, salario) VALUES ($1, $2, $3, $4, $5)',
      [nome, email, senha, cargo, salario]
    );
    res.status(201).json({ mensagem: 'Colaborador cadastrado com sucesso!' });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

exports.listarColaboradores = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM colaboradores');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};