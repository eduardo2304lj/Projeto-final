const pool = require('../config/db');

exports.criarReembolso = async (req, res) => {
  const {
    colaborador_nome, empresa, numero_prestacao, data, tipo, centro_custo,
    ordem_interna, divisao, pep, moeda, distancia_km, valor_km,
    valor_faturado, despesa, colaborador_id, status
  } = req.body;

  try {
    await pool.query(
      'INSERT INTO reembolsos (colaborador_nome, empresa, numero_prestacao, data, tipo, centro_custo, ordem_interna, divisao, pep, moeda, distancia_km, valor_km, valor_faturado, despesa, colaborador_id, status) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)',
      [colaborador_nome, empresa, numero_prestacao, data, tipo, centro_custo, ordem_interna, divisao, pep, moeda, distancia_km, valor_km, valor_faturado, despesa, colaborador_id, status]
    );
    res.status(201).json({ mensagem: 'Reembolso criado com sucesso!' });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

exports.buscarPorNumeroPrestacao = async (req, res) => {
  const { numero } = req.params;
  try {
    const result = await pool.query('SELECT * FROM reembolsos WHERE numero_prestacao = $1', [numero]);
    res.json(result.rows[0] || {});
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};